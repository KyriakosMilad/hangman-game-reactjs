self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6fb91ea38b2b355af7a70c60ab0a2d04",
    "url": "/hangman/index.html"
  },
  {
    "revision": "c093e5137add76ad380f",
    "url": "/hangman/static/css/main.96d6d7bf.chunk.css"
  },
  {
    "revision": "b1f854992a0eb3b5ab0f",
    "url": "/hangman/static/js/2.ebc18933.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/hangman/static/js/2.ebc18933.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c093e5137add76ad380f",
    "url": "/hangman/static/js/main.6d12ee22.chunk.js"
  },
  {
    "revision": "7ef95293683d0ed87720",
    "url": "/hangman/static/js/runtime-main.6b115b9b.js"
  },
  {
    "revision": "db9097e874e68b7ed7115ff05ffcb880",
    "url": "/hangman/static/media/0.db9097e8.jpg"
  },
  {
    "revision": "fbff4784004cc97463c883477a0090d1",
    "url": "/hangman/static/media/1.fbff4784.jpg"
  },
  {
    "revision": "c4ea9528b67823bd94c90de3d97d75a3",
    "url": "/hangman/static/media/2.c4ea9528.jpg"
  },
  {
    "revision": "62a781c89c590abb27129638d9d18c4d",
    "url": "/hangman/static/media/3.62a781c8.jpg"
  },
  {
    "revision": "0f8ca81ee9f7b2bc27102267f9e23864",
    "url": "/hangman/static/media/4.0f8ca81e.jpg"
  },
  {
    "revision": "1b557aa7ccfa88b6b3f4723c27d3f2d6",
    "url": "/hangman/static/media/5.1b557aa7.jpg"
  },
  {
    "revision": "c80394c2a96ffad09a9df4e4815745f2",
    "url": "/hangman/static/media/6.c80394c2.jpg"
  }
]);